"""Fills the database with realistic sample data.

Run from the project root:   python -m database.seed_data
WARNING: this DELETES the existing library.db and rebuilds it from scratch.
"""
import random
import sys
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import LOAN_DAYS
from database.db import get_connection, init_db
from services.auth import hash_password

# (username, password, full name, role)  -> documented in the project documentation
USERS = [
    ("admin", "admin123", "System Administrator", "admin"),
    ("librarian", "lib123", "Mona Librarian", "librarian"),
]

# (title, author, category, year)
BOOKS = [
    ("1984", "George Orwell", "Fiction", 1949),
    ("Animal Farm", "George Orwell", "Fiction", 1945),
    ("Pride and Prejudice", "Jane Austen", "Fiction", 1813),
    ("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", 1925),
    ("To Kill a Mockingbird", "Harper Lee", "Fiction", 1960),
    ("The Alchemist", "Paulo Coelho", "Fiction", 1988),
    ("One Hundred Years of Solitude", "Gabriel Garcia Marquez", "Fiction", 1967),
    ("Crime and Punishment", "Fyodor Dostoevsky", "Fiction", 1866),
    ("The Brothers Karamazov", "Fyodor Dostoevsky", "Fiction", 1880),
    ("Children of the Alley", "Naguib Mahfouz", "Fiction", 1959),
    ("Palace Walk", "Naguib Mahfouz", "Fiction", 1956),
    ("The Thief and the Dogs", "Naguib Mahfouz", "Fiction", 1961),
    ("Les Miserables", "Victor Hugo", "Fiction", 1862),
    ("Don Quixote", "Miguel de Cervantes", "Fiction", 1605),
    ("Moby Dick", "Herman Melville", "Fiction", 1851),
    ("A Brief History of Time", "Stephen Hawking", "Science", 1988),
    ("Cosmos", "Carl Sagan", "Science", 1980),
    ("The Selfish Gene", "Richard Dawkins", "Science", 1976),
    ("The Origin of Species", "Charles Darwin", "Science", 1859),
    ("Astrophysics for People in a Hurry", "Neil deGrasse Tyson", "Science", 2017),
    ("The Elegant Universe", "Brian Greene", "Science", 1999),
    ("Clean Code", "Robert C. Martin", "Technology", 2008),
    ("The Pragmatic Programmer", "Andrew Hunt", "Technology", 1999),
    ("Automate the Boring Stuff with Python", "Al Sweigart", "Technology", 2015),
    ("Python Crash Course", "Eric Matthes", "Technology", 2015),
    ("Introduction to Algorithms", "Thomas H. Cormen", "Technology", 1990),
    ("Design Patterns", "Erich Gamma", "Technology", 1994),
    ("The Mythical Man-Month", "Frederick Brooks", "Technology", 1975),
    ("Code Complete", "Steve McConnell", "Technology", 1993),
    ("Sapiens", "Yuval Noah Harari", "History", 2011),
    ("Guns, Germs, and Steel", "Jared Diamond", "History", 1997),
    ("The History of the Arabs", "Philip K. Hitti", "History", 1937),
    ("A People's History of the United States", "Howard Zinn", "History", 1980),
    ("The Silk Roads", "Peter Frankopan", "History", 2015),
    ("Atomic Habits", "James Clear", "Self-Development", 2018),
    ("The 7 Habits of Highly Effective People", "Stephen R. Covey", "Self-Development", 1989),
    ("How to Win Friends and Influence People", "Dale Carnegie", "Self-Development", 1936),
    ("Deep Work", "Cal Newport", "Self-Development", 2016),
    ("Thinking, Fast and Slow", "Daniel Kahneman", "Self-Development", 2011),
    ("Man's Search for Meaning", "Viktor Frankl", "Self-Development", 1946),
    ("Meditations", "Marcus Aurelius", "Philosophy", None),
    ("The Republic", "Plato", "Philosophy", None),
    ("Beyond Good and Evil", "Friedrich Nietzsche", "Philosophy", 1886),
    ("The Prince", "Niccolo Machiavelli", "Philosophy", 1532),
    ("Sophie's World", "Jostein Gaarder", "Philosophy", 1991),
    ("The Little Prince", "Antoine de Saint-Exupery", "Children", 1943),
    ("Harry Potter and the Philosopher's Stone", "J.K. Rowling", "Children", 1997),
    ("Alice's Adventures in Wonderland", "Lewis Carroll", "Children", 1865),
    ("Charlie and the Chocolate Factory", "Roald Dahl", "Children", 1964),
    ("Matilda", "Roald Dahl", "Children", 1988),
]

MEMBER_NAMES = [
    "Ahmed Hassan", "Mohamed Ali", "Sara Mahmoud", "Mona Ibrahim", "Omar Khaled",
    "Nour Salah", "Youssef Adel", "Hana Tarek", "Mostafa Samir", "Aya Mostafa",
    "Karim Nabil", "Farah Ehab", "Hassan Gamal", "Laila Hesham", "Ali Reda",
    "Dina Fathy", "Tamer Sherif", "Rana Walid", "Mahmoud Essam", "Salma Yasser",
]

N_OVERDUE = 8      # books borrowed and NOT returned, past due date
N_ACTIVE = 7       # books borrowed and NOT returned, still within the period
N_RETURNED = 85    # finished loans (history)


def seed():
    random.seed(42)                       # same data every time
    today = date.today()
    init_db(reset=True)
    conn = get_connection()

    # --- users ---
    for username, password, full_name, role in USERS:
        conn.execute(
            "INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)",
            (username, hash_password(password), full_name, role),
        )
    user_ids = [r["id"] for r in conn.execute("SELECT id FROM users")]

    # --- categories, authors, books ---
    category_ids, author_ids, copies = {}, {}, {}
    for title, author, category, year in BOOKS:
        if category not in category_ids:
            category_ids[category] = conn.execute(
                "INSERT INTO categories (name) VALUES (?)", (category,)).lastrowid
        if author not in author_ids:
            author_ids[author] = conn.execute(
                "INSERT INTO authors (name) VALUES (?)", (author,)).lastrowid
        total = random.choice([1, 2, 2, 3, 3, 4, 5])
        book_id = conn.execute(
            "INSERT INTO books (title, author_id, category_id, publish_year, copies_total, copies_available) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (title, author_ids[author], category_ids[category], year, total, total),
        ).lastrowid
        copies[book_id] = total

    # --- members ---
    member_ids = []
    for name in MEMBER_NAMES:
        first, last = name.lower().split()
        join = today - timedelta(days=random.randint(200, 700))
        member_ids.append(conn.execute(
            "INSERT INTO members (name, phone, email, join_date) VALUES (?, ?, ?, ?)",
            (name, "01" + "".join(random.choices("0123456789", k=9)),
             f"{first}.{last}@example.com", join.isoformat()),
        ).lastrowid)

    # --- loans (some books are borrowed more than others -> interesting reports) ---
    book_ids = list(copies)
    weights = [random.randint(1, 10) for _ in book_ids]
    active_count = {b: 0 for b in book_ids}
    loans = []

    def pick_book(must_have_free_copy):
        while True:
            b = random.choices(book_ids, weights)[0]
            if not must_have_free_copy or active_count[b] < copies[b]:
                return b

    for kind, count in (("overdue", N_OVERDUE), ("active", N_ACTIVE), ("returned", N_RETURNED)):
        for _ in range(count):
            if kind == "overdue":
                loan_date = today - timedelta(days=random.randint(LOAN_DAYS + 5, 60))
                return_date = None
            elif kind == "active":
                loan_date = today - timedelta(days=random.randint(1, LOAN_DAYS - 2))
                return_date = None
            else:
                loan_date = today - timedelta(days=random.randint(20, 180))
                return_date = min(loan_date + timedelta(days=random.randint(2, 24)),
                                  today - timedelta(days=1))
            book = pick_book(must_have_free_copy=(return_date is None))
            if return_date is None:
                active_count[book] += 1
            loans.append((book, random.choice(member_ids), random.choice(user_ids),
                          loan_date.isoformat(),
                          (loan_date + timedelta(days=LOAN_DAYS)).isoformat(),
                          return_date.isoformat() if return_date else None))

    loans.sort(key=lambda row: row[3])    # oldest first
    conn.executemany(
        "INSERT INTO loans (book_id, member_id, issued_by, loan_date, due_date, return_date) "
        "VALUES (?, ?, ?, ?, ?, ?)", loans)

    # keep copies_available consistent with the loans that are still open
    for book_id, total in copies.items():
        conn.execute("UPDATE books SET copies_available = ? WHERE id = ?",
                     (total - active_count[book_id], book_id))

    conn.commit()
    conn.close()
    print(f"Done: {len(USERS)} users, {len(BOOKS)} books, {len(MEMBER_NAMES)} members, {len(loans)} loans.")


if __name__ == "__main__":
    seed()
