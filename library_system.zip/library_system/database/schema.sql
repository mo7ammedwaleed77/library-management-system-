-- ============================================================
-- Library Management System - Database Schema (SQLite)
-- Owner: Person 1.  Any change here must be announced to the team.
-- Dates are stored as TEXT in ISO format: 'YYYY-MM-DD'
-- ============================================================

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,                       -- never plain text
    full_name     TEXT NOT NULL,
    role          TEXT NOT NULL CHECK (role IN ('admin', 'librarian'))
);

CREATE TABLE IF NOT EXISTS members (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    name      TEXT NOT NULL,
    phone     TEXT,
    email     TEXT UNIQUE,
    join_date TEXT NOT NULL DEFAULT (date('now'))
);

CREATE TABLE IF NOT EXISTS categories (
    id   INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS authors (
    id   INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS books (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    title            TEXT NOT NULL,
    author_id        INTEGER NOT NULL REFERENCES authors(id),
    category_id      INTEGER NOT NULL REFERENCES categories(id),
    publish_year     INTEGER,
    copies_total     INTEGER NOT NULL DEFAULT 1 CHECK (copies_total >= 1),
    copies_available INTEGER NOT NULL DEFAULT 1,
    CHECK (copies_available BETWEEN 0 AND copies_total)
);

CREATE TABLE IF NOT EXISTS loans (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id     INTEGER NOT NULL REFERENCES books(id),
    member_id   INTEGER NOT NULL REFERENCES members(id),
    issued_by   INTEGER NOT NULL REFERENCES users(id),  -- librarian who made the loan
    loan_date   TEXT NOT NULL,
    due_date    TEXT NOT NULL,
    return_date TEXT                                    -- NULL = still borrowed
);

CREATE INDEX IF NOT EXISTS idx_books_title   ON books(title);
CREATE INDEX IF NOT EXISTS idx_loans_book    ON loans(book_id);
CREATE INDEX IF NOT EXISTS idx_loans_member  ON loans(member_id);
CREATE INDEX IF NOT EXISTS idx_loans_return  ON loans(return_date);
