"""Loans & Returns screen.   Owner: Person 4

When you build the real screen: delete the ComingSoon card and use self.body, e.g.
    DataTable(self.body, columns=[...]).pack(fill="both", expand=True)
"""
from gui.widgets import ComingSoon, Page


class LoansFrame(Page):
    def __init__(self, parent, user):
        super().__init__(parent, "Loans & Returns", "Borrow books, return them and follow overdue items")
        self.user = user
        ComingSoon(self.body, "Person 4", [
            "Choose a member and a book, then press Borrow  (services.loans.borrow_book)",
            "Table of active loans with a Return button  (services.loans.return_book)",
            "Overdue loans highlighted in red, with days late and fine",
        ]).pack(fill="x")
