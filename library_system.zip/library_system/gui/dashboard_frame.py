"""Dashboard: summary cards + recent activity + overdue list."""
import tkinter as tk

from gui import theme
from gui.widgets import DataTable, Page, Section, StatCard
from services import dashboard


class DashboardFrame(Page):
    def __init__(self, parent, user):
        first_name = user["full_name"].split()[0]
        super().__init__(parent, "Dashboard", f"Welcome back, {first_name}. Here is the library at a glance.")

        # --- row 1: four summary cards ---
        cards = tk.Frame(self.body, bg=theme.IVORY)
        cards.pack(fill="x")
        for column in range(4):
            cards.columnconfigure(column, weight=1, uniform="stat")
        self.stat_books = StatCard(cards, "Book titles", accent=theme.GOLD)
        self.stat_members = StatCard(cards, "Members", accent=theme.NAVY_LIGHT)
        self.stat_active = StatCard(cards, "Active loans", accent=theme.WARNING)
        self.stat_overdue = StatCard(cards, "Overdue", accent=theme.DANGER)
        for column, card in enumerate((self.stat_books, self.stat_members,
                                       self.stat_active, self.stat_overdue)):
            card.grid(row=0, column=column, sticky="nsew", padx=(0 if column == 0 else 8, 0))

        # --- row 2: two tables side by side ---
        row = tk.Frame(self.body, bg=theme.IVORY)
        row.pack(fill="both", expand=True, pady=(16, 0))
        row.columnconfigure(0, weight=3, uniform="split")
        row.columnconfigure(1, weight=2, uniform="split")
        row.rowconfigure(0, weight=1)

        recent = Section(row, "Recent activity", "Latest borrowing transactions")
        recent.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        self.recent_table = DataTable(recent.content, bordered=False, height=7, columns=[
            ("title", "Book", 180, "w"), ("member", "Member", 120, "w"),
            ("date", "Date", 85, "center"), ("status", "Status", 80, "center")])
        self.recent_table.pack(fill="both", expand=True)

        late = Section(row, "Overdue now", "Books that should have been returned")
        late.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        self.overdue_table = DataTable(late.content, bordered=False, height=7, columns=[
            ("title", "Book", 150, "w"), ("member", "Member", 100, "w"),
            ("days", "Days late", 60, "center")])
        self.overdue_table.pack(fill="both", expand=True)

        self.refresh()

    def refresh(self):
        stats = dashboard.get_stats()
        self.stat_books.set(stats["titles"], f'{stats["copies"]} copies in total')
        self.stat_members.set(stats["members"], "registered members")
        self.stat_active.set(stats["active_loans"], "currently borrowed")
        if stats["overdue"]:
            self.stat_overdue.set(stats["overdue"], "need follow-up", theme.DANGER)
        else:
            self.stat_overdue.set(0, "everything is on time", theme.SUCCESS)

        recent = dashboard.get_recent_loans()
        status_tags = {"Overdue": "danger", "Returned": "muted", "Borrowed": None}
        self.recent_table.load(
            [(r["title"], r["member"], r["loan_date"], r["status"]) for r in recent],
            tags=[status_tags[r["status"]] for r in recent])

        overdue = dashboard.get_overdue_preview()
        self.overdue_table.load(
            [(r["title"], r["member"], r["days_late"]) for r in overdue],
            tags=["danger"] * len(overdue))
