"""Reports & Statistics screen (admin only).   Owner: Person 5

Already works: Report 1 (most borrowed books).
TODO (Person 5): the other reports. Idea: a Combobox at the top to choose the report,
and one DataTable whose columns change (or one Section per report).
"""
from gui import theme
from gui.widgets import DataTable, Page, Section, label
from services import reports


class ReportsFrame(Page):
    def __init__(self, parent, user):
        super().__init__(parent, "Reports & Statistics", "Insights calculated from the loan history")
        self.user = user

        section = Section(self.body, "Most borrowed books", "Ranked by number of times borrowed")
        section.pack(fill="both", expand=True)
        self.table = DataTable(section.content, bordered=False, height=10, columns=[
            ("rank", "#", 50, "center"), ("title", "Title", 320, "w"),
            ("author", "Author", 220, "w"), ("times", "Times borrowed", 130, "center")])
        self.table.pack(fill="both", expand=True)

        label(self.body, "More reports coming: overdue books, loans per month, books per category.",
              9, fg=theme.MUTED).pack(anchor="w", pady=(10, 0))
        self.refresh()

    def refresh(self):
        rows = [(i, r["title"], r["author"], r["times_borrowed"])
                for i, r in enumerate(reports.most_borrowed_books(), start=1)]
        self.table.load(rows)
