"""Login screen (split layout: brand panel + form).   Owner: Person 2"""
import tkinter as tk
from tkinter import ttk

from gui import theme
from gui.widgets import label
from services import auth


class LoginFrame(tk.Frame):
    def __init__(self, parent, on_login_success):
        super().__init__(parent, bg=theme.IVORY)
        self.on_login_success = on_login_success

        # ---------- left: brand panel ----------
        left = tk.Frame(self, bg=theme.NAVY, width=460)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)
        brand = tk.Frame(left, bg=theme.NAVY)
        brand.place(relx=0.5, rely=0.5, anchor="center")
        tk.Label(brand, text="◆", font=theme.font(40, "bold"), fg=theme.GOLD, bg=theme.NAVY).pack()
        tk.Label(brand, text="LIBRARY", font=theme.font(30, "bold"), fg="white",
                 bg=theme.NAVY).pack(pady=(6, 0))
        tk.Label(brand, text="MANAGEMENT SYSTEM", font=theme.font(10, "bold"), fg=theme.GOLD,
                 bg=theme.NAVY).pack(pady=(2, 18))
        tk.Frame(brand, bg=theme.GOLD, height=2, width=60).pack()
        tk.Label(brand, text="Books, members and loans,\nbeautifully organized.",
                 font=theme.font(11), fg=theme.ON_NAVY_MUTED, bg=theme.NAVY,
                 justify="center").pack(pady=18)

        # ---------- right: form ----------
        right = tk.Frame(self, bg=theme.IVORY)
        right.pack(side="left", fill="both", expand=True)
        form = tk.Frame(right, bg=theme.IVORY)
        form.place(relx=0.5, rely=0.5, anchor="center")

        label(form, "Welcome back", 24, "bold", theme.NAVY).pack(anchor="w")
        label(form, "Sign in to your account to continue", 10, fg=theme.MUTED).pack(anchor="w", pady=(2, 24))

        label(form, "USERNAME", 8, "bold", theme.MUTED).pack(anchor="w")
        self.username_entry = ttk.Entry(form, width=34, font=theme.font(11))
        self.username_entry.pack(fill="x", pady=(4, 14))

        label(form, "PASSWORD", 8, "bold", theme.MUTED).pack(anchor="w")
        self.password_entry = ttk.Entry(form, width=34, font=theme.font(11), show="•")
        self.password_entry.pack(fill="x", pady=(4, 20))

        ttk.Button(form, text="Sign in", style="Primary.TButton",
                   command=self.attempt_login).pack(fill="x")
        self.error_label = label(form, "", 10, fg=theme.DANGER)
        self.error_label.pack(anchor="w", pady=(12, 0))

        self.username_entry.focus()
        self.username_entry.bind("<Return>", lambda event: self.password_entry.focus())
        self.password_entry.bind("<Return>", lambda event: self.attempt_login())

    def attempt_login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        if not username or not password:
            self.error_label.config(text="Please enter your username and password.")
            return
        user = auth.login(username, password)
        if user is None:
            self.error_label.config(text="Wrong username or password.")
            self.password_entry.delete(0, "end")
            return
        self.on_login_success(user)
