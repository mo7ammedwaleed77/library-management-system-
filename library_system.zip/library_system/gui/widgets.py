"""Reusable building blocks, so every screen looks the same.

    Page         -> base class of every screen (title + gold underline + self.body)
    Card/Section -> white rounded-looking box with a thin border
    StatCard     -> big number with a label (dashboard)
    DataTable    -> styled table (Treeview) with scrollbar and zebra rows
    ComingSoon   -> placeholder card for screens that are still TODO
    label(), badge() -> small helpers

Buttons: ttk.Button(parent, text="Save", style="Primary.TButton")
         styles: Primary.TButton (gold) | Secondary.TButton | Danger.TButton
"""
import tkinter as tk
from tkinter import ttk

from gui import theme


def label(parent, text="", size=10, weight="normal", fg=None, bg=None, **options):
    """A tk.Label with the theme font/colors. bg defaults to the page color."""
    options.setdefault("anchor", "w")
    options.setdefault("justify", "left")
    return tk.Label(parent, text=text, font=theme.font(size, weight),
                    fg=fg or theme.TEXT, bg=bg or theme.IVORY, **options)


def badge(parent, text, bg=None, fg=None):
    """Small colored pill-like label."""
    return tk.Label(parent, text=text, font=theme.font(8, "bold"), padx=8, pady=2,
                    bg=bg or theme.GOLD, fg=fg or theme.NAVY_DARK)


class Page(tk.Frame):
    """Base class for screens. Put your widgets inside self.body."""

    def __init__(self, parent, title, subtitle=""):
        super().__init__(parent, bg=theme.IVORY)
        head = tk.Frame(self, bg=theme.IVORY)
        head.pack(fill="x", padx=32, pady=(26, 0))
        label(head, title, 22, "bold", theme.NAVY).pack(anchor="w")
        if subtitle:
            label(head, subtitle, 10, fg=theme.MUTED).pack(anchor="w", pady=(2, 0))
        tk.Frame(head, bg=theme.GOLD, height=3, width=48).pack(anchor="w", pady=(10, 0))

        self.body = tk.Frame(self, bg=theme.IVORY)
        self.body.pack(fill="both", expand=True, padx=32, pady=(18, 24))


class Card(tk.Frame):
    """White box with a thin border. Put content inside card.inner."""

    def __init__(self, parent, padding=16):
        super().__init__(parent, bg=theme.CARD, highlightthickness=1,
                         highlightbackground=theme.BORDER, highlightcolor=theme.BORDER)
        self.inner = tk.Frame(self, bg=theme.CARD)
        self.inner.pack(fill="both", expand=True, padx=padding, pady=padding)


class Section(Card):
    """Card with a title. Put content inside section.content."""

    def __init__(self, parent, title, subtitle=""):
        super().__init__(parent, padding=18)
        label(self.inner, title, 13, "bold", theme.NAVY, theme.CARD).pack(anchor="w")
        if subtitle:
            label(self.inner, subtitle, 9, fg=theme.MUTED, bg=theme.CARD).pack(anchor="w")
        self.content = tk.Frame(self.inner, bg=theme.CARD)
        self.content.pack(fill="both", expand=True, pady=(12, 0))


class StatCard(tk.Frame):
    """Big number + caption, with a colored bar on the left."""

    def __init__(self, parent, title, value="0", note="", accent=None):
        super().__init__(parent, bg=theme.CARD, highlightthickness=1,
                         highlightbackground=theme.BORDER, highlightcolor=theme.BORDER)
        self.bar = tk.Frame(self, bg=accent or theme.GOLD, width=5)
        self.bar.pack(side="left", fill="y")
        box = tk.Frame(self, bg=theme.CARD)
        box.pack(side="left", fill="both", expand=True, padx=18, pady=14)
        label(box, title.upper(), 8, "bold", theme.MUTED, theme.CARD).pack(anchor="w")
        self.value_label = label(box, str(value), 28, "bold", theme.NAVY, theme.CARD)
        self.value_label.pack(anchor="w", pady=(2, 0))
        self.note_label = label(box, note, 9, fg=theme.MUTED, bg=theme.CARD)
        self.note_label.pack(anchor="w")

    def set(self, value, note=None, accent=None):
        self.value_label.config(text=str(value))
        if note is not None:
            self.note_label.config(text=note)
        if accent is not None:
            self.bar.config(bg=accent)


class DataTable(tk.Frame):
    """Styled table.

    columns = [(key, heading, width, anchor), ...]      anchor: "w" | "center" | "e"
    table.load(rows, tags=None)   rows = list of tuples in the same order as columns
                                  tags = optional list (same length) of "danger"/"success"/"muted"
    table.selected()              -> tuple of the selected row's values, or None
    """

    def __init__(self, parent, columns, height=12, bordered=True):
        super().__init__(parent, bg=theme.CARD, highlightthickness=1 if bordered else 0,
                         highlightbackground=theme.BORDER, highlightcolor=theme.BORDER)
        keys = [col[0] for col in columns]
        self.tree = ttk.Treeview(self, columns=keys, show="headings", height=height,
                                 selectmode="browse")
        for key, heading, width, anchor in columns:
            self.tree.heading(key, text=heading, anchor=anchor)
            self.tree.column(key, width=width, minwidth=40, anchor=anchor, stretch=True)

        scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.tree.tag_configure("even", background=theme.CARD)
        self.tree.tag_configure("odd", background=theme.ROW_ALT)
        self.tree.tag_configure("danger", foreground=theme.DANGER)
        self.tree.tag_configure("success", foreground=theme.SUCCESS)
        self.tree.tag_configure("muted", foreground=theme.MUTED)

    def clear(self):
        self.tree.delete(*self.tree.get_children())

    def load(self, rows, tags=None):
        self.clear()
        for index, row in enumerate(rows):
            values = tuple("" if value is None else value for value in row)
            row_tags = ["odd" if index % 2 else "even"]
            if tags and tags[index]:
                row_tags.append(tags[index])
            self.tree.insert("", "end", values=values, tags=tuple(row_tags))

    def selected(self):
        selection = self.tree.selection()
        return self.tree.item(selection[0], "values") if selection else None


class ComingSoon(Card):
    """Placeholder for a screen that is not implemented yet. Delete it when you build the real screen."""

    def __init__(self, parent, owner, steps):
        super().__init__(parent, padding=24)
        badge(self.inner, "IN DEVELOPMENT").pack(anchor="w")
        label(self.inner, f"This screen is assigned to {owner}", 14, "bold", theme.NAVY,
              theme.CARD).pack(anchor="w", pady=(12, 4))
        label(self.inner, "What needs to be built:", 10, fg=theme.MUTED, bg=theme.CARD).pack(anchor="w")
        for step in steps:
            label(self.inner, "•  " + step, 10, bg=theme.CARD).pack(anchor="w", pady=(4, 0))
