"""Visual theme: colors, fonts and ttk styles for the WHOLE app.

Change a color here and every screen changes with it.
Palette: deep navy + antique gold on a warm ivory background.
"""
from tkinter import font as tkfont
from tkinter import ttk

# ---------- Palette ----------
NAVY_DARK = "#0B1626"
NAVY = "#12233B"
NAVY_HOVER = "#182B46"
NAVY_LIGHT = "#1E3A5F"
GOLD = "#C9A227"
GOLD_LIGHT = "#DDBE55"
GOLD_DARK = "#A88A1C"
IVORY = "#F6F3EC"        # page background
CARD = "#FFFFFF"
ROW_ALT = "#FAF8F3"      # zebra rows in tables
BORDER = "#E3DED2"
TEXT = "#1B2533"
MUTED = "#6B7280"
SUCCESS = "#2E7D5B"
DANGER = "#B3261E"
WARNING = "#B7791F"
SELECT_BG = "#F2E6B8"
ON_NAVY = "#FFFFFF"
ON_NAVY_MUTED = "#9FB0C8"

_font_family = "Helvetica"


def font(size=10, weight="normal"):
    """Use everywhere:  font=theme.font(12, "bold")"""
    return (_font_family, size, weight)


def apply(root):
    """Call once, right after creating the main window."""
    global _font_family
    available = set(tkfont.families(root))
    for name in ("Segoe UI", "SF Pro Text", "Helvetica Neue", "Ubuntu", "Cantarell", "DejaVu Sans"):
        if name in available:
            _font_family = name
            break

    for named in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont"):
        tkfont.nametofont(named).configure(family=_font_family, size=10)

    root.configure(bg=IVORY)
    # drop-down list of the Combobox
    root.option_add("*TCombobox*Listbox.background", CARD)
    root.option_add("*TCombobox*Listbox.foreground", TEXT)
    root.option_add("*TCombobox*Listbox.selectBackground", SELECT_BG)
    root.option_add("*TCombobox*Listbox.selectForeground", TEXT)

    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure(".", background=IVORY, foreground=TEXT, font=font(10))

    # ---------- Buttons ----------
    def button(name, bg, fg, hover, pressed, border):
        style.configure(name, background=bg, foreground=fg, bordercolor=border, lightcolor=bg,
                        darkcolor=bg, focuscolor=bg, borderwidth=1, relief="flat",
                        padding=(18, 9), font=font(10, "bold"))
        style.map(name,
                  background=[("disabled", BORDER), ("pressed", pressed), ("active", hover)],
                  bordercolor=[("pressed", pressed), ("active", hover)],
                  lightcolor=[("pressed", pressed), ("active", hover)],
                  darkcolor=[("pressed", pressed), ("active", hover)],
                  foreground=[("disabled", MUTED)])

    button("TButton", CARD, NAVY, "#F3F0E8", "#E8E4D8", BORDER)
    button("Primary.TButton", GOLD, NAVY_DARK, GOLD_LIGHT, GOLD_DARK, GOLD)
    button("Secondary.TButton", CARD, NAVY, "#F3F0E8", "#E8E4D8", BORDER)
    button("Danger.TButton", DANGER, "#FFFFFF", "#C9362D", "#8F1D17", DANGER)
    button("Sidebar.TButton", NAVY_LIGHT, "#FFFFFF", "#27497A", NAVY_HOVER, NAVY_LIGHT)

    # ---------- Inputs ----------
    focus = [("focus", GOLD)]
    style.configure("TEntry", fieldbackground=CARD, foreground=TEXT, bordercolor=BORDER,
                    lightcolor=BORDER, darkcolor=BORDER, insertcolor=TEXT, padding=(8, 7))
    style.map("TEntry", bordercolor=focus, lightcolor=focus, darkcolor=focus)

    style.configure("TCombobox", fieldbackground=CARD, background=CARD, foreground=TEXT,
                    arrowcolor=NAVY, bordercolor=BORDER, lightcolor=BORDER, darkcolor=BORDER,
                    padding=(8, 6))
    style.map("TCombobox", fieldbackground=[("readonly", CARD)], foreground=[("readonly", TEXT)],
              bordercolor=focus, lightcolor=focus, darkcolor=focus)

    # ---------- Tables ----------
    style.layout("Treeview", [("Treeview.treearea", {"sticky": "nswe"})])   # remove the ugly border
    style.configure("Treeview", background=CARD, fieldbackground=CARD, foreground=TEXT,
                    rowheight=32, borderwidth=0, font=font(10))
    style.map("Treeview", background=[("selected", SELECT_BG)], foreground=[("selected", TEXT)])
    style.configure("Treeview.Heading", background=NAVY, foreground="#FFFFFF", relief="flat",
                    borderwidth=0, padding=(10, 9), font=font(10, "bold"))
    style.map("Treeview.Heading", background=[("active", NAVY_LIGHT)], relief=[("pressed", "flat")])

    # ---------- Scrollbar ----------
    style.configure("Vertical.TScrollbar", background=BORDER, troughcolor=CARD, bordercolor=CARD,
                    lightcolor=BORDER, darkcolor=BORDER, arrowcolor=MUTED, arrowsize=14)
    style.map("Vertical.TScrollbar", background=[("active", "#CFC8B8")])
