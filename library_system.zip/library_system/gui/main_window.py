"""Main window: dark sidebar navigation + content area.

To add a new screen: create the Page class, then add one line to ROUTES below.
Format: (key, menu text, screen class, admin_only)
"""
import tkinter as tk
from tkinter import ttk

from gui import theme
from gui.books_frame import BooksFrame
from gui.dashboard_frame import DashboardFrame
from gui.loans_frame import LoansFrame
from gui.members_frame import MembersFrame
from gui.reports_frame import ReportsFrame

ROUTES = [
    ("dashboard", "Dashboard", DashboardFrame, False),
    ("books", "Books", BooksFrame, False),
    ("members", "Members", MembersFrame, False),
    ("loans", "Loans & Returns", LoansFrame, False),
    ("reports", "Reports & Statistics", ReportsFrame, True),   # admin only
]


class NavItem(tk.Frame):
    """One entry of the sidebar menu."""

    def __init__(self, parent, text, command):
        super().__init__(parent, bg=theme.NAVY, cursor="hand2")
        self.active = False
        self.indicator = tk.Frame(self, width=4, bg=theme.NAVY)
        self.indicator.pack(side="left", fill="y")
        self.text = tk.Label(self, text=text, anchor="w", padx=22, pady=13, font=theme.font(11),
                             fg=theme.ON_NAVY_MUTED, bg=theme.NAVY, cursor="hand2")
        self.text.pack(side="left", fill="x", expand=True)
        for widget in (self, self.indicator, self.text):
            widget.bind("<Button-1>", lambda event: command())
            widget.bind("<Enter>", lambda event: self._paint(hover=True))
            widget.bind("<Leave>", lambda event: self._paint(hover=False))

    def set_active(self, active):
        self.active = active
        self._paint()

    def _paint(self, hover=False):
        if self.active:
            bg, fg, bar = theme.NAVY_LIGHT, "white", theme.GOLD
        elif hover:
            bg, fg, bar = theme.NAVY_HOVER, "white", theme.NAVY_HOVER
        else:
            bg, fg, bar = theme.NAVY, theme.ON_NAVY_MUTED, theme.NAVY
        self.configure(bg=bg)
        self.text.configure(bg=bg, fg=fg)
        self.indicator.configure(bg=bar)


class MainWindow(tk.Frame):
    def __init__(self, parent, user, on_logout):
        super().__init__(parent, bg=theme.IVORY)
        self.user = user
        self.pages = {}        # key -> screen (created the first time it is opened)
        self.nav_items = {}    # key -> NavItem
        self.current = None

        self._build_sidebar(on_logout)
        self.content = tk.Frame(self, bg=theme.IVORY)
        self.content.pack(side="left", fill="both", expand=True)
        self.show("dashboard")

    # ---------- sidebar ----------
    def _build_sidebar(self, on_logout):
        sidebar = tk.Frame(self, bg=theme.NAVY, width=250)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        brand = tk.Frame(sidebar, bg=theme.NAVY)
        brand.pack(fill="x", padx=22, pady=(28, 6))
        tk.Label(brand, text="◆", font=theme.font(20, "bold"), fg=theme.GOLD,
                 bg=theme.NAVY).pack(side="left")
        names = tk.Frame(brand, bg=theme.NAVY)
        names.pack(side="left", padx=10)
        tk.Label(names, text="LIBRARY", font=theme.font(14, "bold"), fg="white",
                 bg=theme.NAVY).pack(anchor="w")
        tk.Label(names, text="Management System", font=theme.font(8), fg=theme.ON_NAVY_MUTED,
                 bg=theme.NAVY).pack(anchor="w")
        tk.Frame(sidebar, bg=theme.NAVY_LIGHT, height=1).pack(fill="x", padx=22, pady=(18, 14))

        # user box at the bottom (packed first so it keeps its place)
        box = tk.Frame(sidebar, bg=theme.NAVY_DARK)
        box.pack(side="bottom", fill="x")
        inner = tk.Frame(box, bg=theme.NAVY_DARK)
        inner.pack(fill="x", padx=18, pady=16)
        row = tk.Frame(inner, bg=theme.NAVY_DARK)
        row.pack(fill="x")
        tk.Label(row, text=self.user["full_name"][0].upper(), width=3, bg=theme.GOLD,
                 fg=theme.NAVY_DARK, font=theme.font(13, "bold")).pack(side="left")
        info = tk.Frame(row, bg=theme.NAVY_DARK)
        info.pack(side="left", padx=12)
        tk.Label(info, text=self.user["full_name"], font=theme.font(10, "bold"), fg="white",
                 bg=theme.NAVY_DARK).pack(anchor="w")
        tk.Label(info, text=self.user["role"].upper(), font=theme.font(8, "bold"), fg=theme.GOLD,
                 bg=theme.NAVY_DARK).pack(anchor="w")
        ttk.Button(inner, text="Log out", style="Sidebar.TButton",
                   command=on_logout).pack(fill="x", pady=(14, 0))

        # menu items (role-based: admin-only screens are hidden from other users)
        for key, text, _screen, admin_only in ROUTES:
            if admin_only and self.user["role"] != "admin":
                continue
            item = NavItem(sidebar, text, lambda k=key: self.show(k))
            item.pack(fill="x")
            self.nav_items[key] = item

    # ---------- navigation ----------
    def show(self, key):
        if self.current is not None:
            self.pages[self.current].pack_forget()
            self.nav_items[self.current].set_active(False)

        if key not in self.pages:
            screen_class = next(r[2] for r in ROUTES if r[0] == key)
            self.pages[key] = screen_class(self.content, self.user)
        else:
            refresh = getattr(self.pages[key], "refresh", None)   # keep data up to date
            if callable(refresh):
                refresh()

        self.pages[key].pack(fill="both", expand=True)
        self.nav_items[key].set_active(True)
        self.current = key
