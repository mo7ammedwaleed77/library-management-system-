"""Members screen.   Owner: Person 4

Already works: the styled table with all members.
TODO (Person 4): search box inside self.toolbar, Add / Edit / Delete buttons.
"""
import tkinter as tk

from gui import theme
from gui.widgets import DataTable, Page, label
from services import members


class MembersFrame(Page):
    def __init__(self, parent, user):
        super().__init__(parent, "Members", "Library members and their contact details")
        self.user = user

        self.toolbar = tk.Frame(self.body, bg=theme.IVORY)
        self.toolbar.pack(fill="x", pady=(0, 12))
        self.count_label = label(self.toolbar, "", 10, fg=theme.MUTED)
        self.count_label.pack(side="right")

        self.table = DataTable(self.body, columns=[
            ("id", "ID", 55, "center"), ("name", "Name", 220, "w"), ("phone", "Phone", 140, "w"),
            ("email", "Email", 270, "w"), ("joined", "Joined", 110, "center")])
        self.table.pack(fill="both", expand=True)
        self.refresh()

    def refresh(self):
        rows = [(m["id"], m["name"], m["phone"], m["email"], m["join_date"])
                for m in members.get_all_members()]
        self.table.load(rows)
        self.count_label.config(text=f"{len(rows)} members")
