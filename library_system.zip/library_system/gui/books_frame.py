"""Books screen.   Owner: Person 3

Already works: the styled table with all books (red = no copies available).
TODO (Person 3):
  - search box (title / author) + category filter + status filter, inside self.toolbar
  - Add / Edit / Delete buttons  ->  ttk.Button(..., style="Primary.TButton")
  - hide the Delete button when user["role"] != "admin"
"""
import tkinter as tk

from gui import theme
from gui.widgets import DataTable, Page, label
from services import books


class BooksFrame(Page):
    def __init__(self, parent, user):
        super().__init__(parent, "Books", "Browse and manage the library catalogue")
        self.user = user

        # Toolbar: search/filter/buttons go here (TODO Person 3)
        self.toolbar = tk.Frame(self.body, bg=theme.IVORY)
        self.toolbar.pack(fill="x", pady=(0, 12))
        self.count_label = label(self.toolbar, "", 10, fg=theme.MUTED)
        self.count_label.pack(side="right")

        self.table = DataTable(self.body, columns=[
            ("id", "ID", 55, "center"), ("title", "Title", 300, "w"), ("author", "Author", 190, "w"),
            ("category", "Category", 130, "w"), ("year", "Year", 70, "center"),
            ("available", "Available", 90, "center")])
        self.table.pack(fill="both", expand=True)
        self.refresh()

    def refresh(self):
        """Reload the table from the database."""
        rows, tags = [], []
        for b in books.get_all_books():
            rows.append((b["id"], b["title"], b["author"], b["category"], b["publish_year"],
                         f'{b["copies_available"]} / {b["copies_total"]}'))
            tags.append("danger" if b["copies_available"] == 0 else None)
        self.table.load(rows, tags)
        self.count_label.config(text=f"{len(rows)} books")
