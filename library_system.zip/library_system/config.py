"""Global settings shared by all modules. Change values here, not inside the code."""

APP_TITLE = "Library Management System"
LOAN_DAYS = 14          # how many days a book can be borrowed
FINE_PER_DAY = 2.0      # fine (EGP) for each overdue day
