# Library Management System

مشروع كورس بايثون - تيم 5 أفراد. (Python + Tkinter + SQLite)

## التشغيل (أول مرة)

```
python main.py
```

لو ملف `library.db` مش موجود، البرنامج بيبنيه لوحده بالداتا التجريبية.
لو عايزين تعيدوا بناء الداتا من الصفر: `python -m database.seed_data`
(**تحذير:** بيمسح الداتا القديمة).

## حسابات الاختبار

| الدور | Username | Password |
|---|---|---|
| Admin | `admin` | `admin123` |
| Librarian | `librarian` | `lib123` |

الـ Admin بيشوف تاب التقارير. الـ Librarian مش بيشوفه (ممكن تزودوا فروق تانية: الحذف، إدارة المستخدمين).

## الداتا التجريبية
50 كتاب، 20 عضو، 100 عملية استعارة (منهم 15 لسه معارين و8 منهم متأخرين).

## الهيكل ومين مسؤول عن إيه

| الملفات | المسؤول |
|---|---|
| `database/schema.sql`, `database/db.py`, `database/seed_data.py`, الـ ERD | الشخص 1 |
| `services/auth.py`, `gui/login.py`, إدارة المستخدمين (+ تاب Users للـ admin) | الشخص 2 |
| `services/books.py`, `gui/books_frame.py` | الشخص 3 |
| `services/members.py`, `services/loans.py`, `gui/members_frame.py`, `gui/loans_frame.py` | الشخص 4 |
| `services/reports.py`, `gui/reports_frame.py`, `services/dashboard.py`, `gui/dashboard_frame.py`, `docs/`, الفيديو، تجميع التسليم | الشخص 5 |

كل واحد بيدور على كلمة `TODO` في ملفاته، وده شغله.
اللي مكتوب فيه "EXAMPLE - already working" ده مثال جاهز تقلدوه في باقي الدوال.

## قواعد الشغل

1. **قبل ما تبدأ كل يوم:** `git pull`
2. **بعد ما تخلص حاجة شغالة:**
   ```
   git add .
   git commit -m "وصف قصير"
   git push
   ```
3. اشتغل في ملفاتك بس. لو محتاج تغير في ملف حد تاني، قوله الأول.
4. **ممنوع تغيير أسماء الدوال الموجودة** من غير ما تقولوا للكل (الواجهة معتمدة عليها).
5. **ممنوع تكتب SQL بـ f-string.** استخدم `?` دايماً.
6. كل ما تستخدم AI في جزء، سجله في `docs/AI_usage.md` في نفس اللحظة.
7. `library.db` موجود في `.gitignore` علشان ما يعملش مشاكل دمج، وكل واحد يبني نسخته بـ `python -m database.seed_data`.
   **قبل التسليم النهائي** امسحوا سطر `library.db` من `.gitignore` وحطوا الملف في التسليم.

## ترتيب البداية المقترح

1. الشخص 1: يراجع `schema.sql`، يفتح `library.db` في DB Browser، ويقول للتيم لو عايز يعدل أي جدول (قبل **28 نوفمبر**).
2. الباقي: شغلوا `python main.py`، ادخلوا بالحسابين، واتفرجوا على الكود بتاعكم.
3. كل واحد يحل أول `TODO` في ملفه (دوال الـ services الأول، بعدين الواجهة).

## الـ ERD
فيه ملف `docs/erd.dbml`. ألصقوه في https://dbdiagram.io وهيرسم الـ ERD لوحده، وبعدين Export كصورة أو PDF.

## الشكل والتصميم (Design System)

الألوان والخطوط والأزرار كلها متجمعة في ملفين مشتركين. **متعدلوش فيهم من غير ما تقولوا للتيم:**

| الملف | فيه إيه |
|---|---|
| `gui/theme.py` | الألوان (كحلي + ذهبي + عاجي)، الخطوط، وستايل الأزرار والجداول وحقول الإدخال |
| `gui/widgets.py` | عناصر جاهزة تستخدموها في أي شاشة جديدة |
| `gui/main_window.py` | القايمة الجانبية. شاشة جديدة = سطر واحد في `ROUTES` |

عناصر جاهزة (بتستخدموها بدل ما ترسموا من الصفر):

```python
from gui.widgets import Page, Section, DataTable, StatCard, label
from tkinter import ttk

class MyScreen(Page):                       # كل شاشة بتورّث من Page
    def __init__(self, parent, user):
        super().__init__(parent, "Title", "وصف صغير")
        # حطوا كل حاجة جوه self.body

        self.table = DataTable(self.body, columns=[
            ("id", "ID", 55, "center"), ("name", "Name", 200, "w")])
        self.table.pack(fill="both", expand=True)
        self.table.load([(1, "Ahmed"), (2, "Sara")])      # تعبئة الجدول
        row = self.table.selected()                       # الصف المحدد

        ttk.Button(self.body, text="Save", style="Primary.TButton")   # زرار ذهبي
        # styles تانية: Secondary.TButton  |  Danger.TButton
```

- لو الشاشة عندها دالة `refresh()` القايمة بتستدعيها كل ما تفتحوا الشاشة، فالبيانات بتفضل محدّثة.
- الصف الأحمر في الجداول: `table.load(rows, tags=["danger", None, ...])`.
- مفيش حد يكتب ألوان بإيده (`"#ff0000"`). استخدموا `theme.DANGER` و`theme.GOLD`... إلخ.
