# Project Documentation  (copy into Word/PDF for submission)

## 1. Project title
Library Management System

## 2. Team members
| Name | Edu ID | Practical section | Role / coding tasks |
|---|---|---|---|
| Person 1 |  |  | Database design, schema.sql, seed data, ERD |
| Person 2 |  |  | Authentication, roles, password hashing, user management |
| Person 3 |  |  | Books screen: CRUD, search, filtering |
| Person 4 |  |  | Members, borrowing/returning, overdue and fines |
| Person 5 |  |  | Reports & statistics screen, documentation, demo video, integration |

## 3. Project idea and system description
(Problem: who uses it, what it solves. Describe the 4 core features: books, members, borrowing/returns, overdue tracking.)

## 4. Database description
(Paste the ERD image. Explain each table, its PK, FKs and the relationships: one author -> many books, one category -> many books, one book -> many loans, one member -> many loans, one user -> many loans.)

## 5. Search and filtering
(What can be searched and filtered, and on which screen.)

## 6. Reports and statistics
(List each report and its purpose.)

## 7. Default test accounts
| Role | Username | Password |
|---|---|---|
| Admin | admin | admin123 |
| Librarian | librarian | lib123 |

## 8. Python's role in the project
(Python + Tkinter for the GUI, sqlite3 for the database, hashlib for password hashing, datetime for due dates and fines.)

## 9. AI tools usage
(Short summary + refer to docs/AI_usage.md)

## 10. How to run
Install Python 3.11+, then run `python main.py` from the project folder.

## 11. User guide (optional)
