# AI Tools Usage (mandatory deliverable)

Fill this in WHILE you work. Add a row every time you use an AI tool.

| Team member | AI tool | Project component / file | Type of assistance | Did you understand and modify the result? |
|---|---|---|---|---|
| Example: Person 3 | Claude | services/books.py - search_books | Explained SQL LIKE and wrote a first version | Yes, I changed the filters and tested it |
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |

Overall summary (write 3-4 lines at the end): which tools the team used, for what kinds of tasks, and how the team made sure it understood the generated code.
