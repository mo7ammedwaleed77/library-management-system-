"""Entry point.  Run with:   python main.py"""
import tkinter as tk

import config
from database.db import db_exists
from database.seed_data import seed
from gui import theme
from gui.login import LoginFrame
from gui.main_window import MainWindow


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(config.APP_TITLE)
        theme.apply(self)                       # colors, fonts, ttk styles
        self.minsize(1000, 640)
        self._center(1200, 720)
        self.current_frame = None
        self.show_login()

    def _center(self, width, height):
        """Open the window in the middle of the screen (and never taller than the screen)."""
        screen_w, screen_h = self.winfo_screenwidth(), self.winfo_screenheight()
        height = min(height, screen_h - 80)
        self.geometry(f"{width}x{height}+{(screen_w - width) // 2}+{(screen_h - height) // 3}")

    def _switch_to(self, frame):
        """Replace whatever is on the screen with a new frame."""
        if self.current_frame is not None:
            self.current_frame.destroy()
        self.current_frame = frame
        frame.pack(fill="both", expand=True)

    def show_login(self):
        self._switch_to(LoginFrame(self, on_login_success=self.show_main))

    def show_main(self, user):
        self._switch_to(MainWindow(self, user, on_logout=self.show_login))


if __name__ == "__main__":
    if not db_exists():          # first run: build the database with sample data
        seed()
    App().mainloop()
