"""Queries used by the Dashboard screen (summary numbers + recent activity)."""
from datetime import date

from database.db import get_connection


def get_stats():
    """Dict with: titles, copies, members, active_loans, overdue."""
    conn = get_connection()
    row = conn.execute("""
        SELECT
          (SELECT COUNT(*) FROM books)                                   AS titles,
          (SELECT COALESCE(SUM(copies_total), 0) FROM books)             AS copies,
          (SELECT COUNT(*) FROM members)                                 AS members,
          (SELECT COUNT(*) FROM loans WHERE return_date IS NULL)         AS active_loans,
          (SELECT COUNT(*) FROM loans
            WHERE return_date IS NULL AND due_date < ?)                  AS overdue
    """, (date.today().isoformat(),)).fetchone()
    conn.close()
    return dict(row)


def get_recent_loans(limit=8):
    """Latest loans with a status: Returned / Borrowed / Overdue."""
    conn = get_connection()
    rows = conn.execute("""
        SELECT b.title, m.name AS member, l.loan_date,
               CASE WHEN l.return_date IS NOT NULL THEN 'Returned'
                    WHEN l.due_date < ? THEN 'Overdue'
                    ELSE 'Borrowed' END AS status
        FROM loans l
        JOIN books b   ON b.id = l.book_id
        JOIN members m ON m.id = l.member_id
        ORDER BY l.loan_date DESC, l.id DESC
        LIMIT ?
    """, (date.today().isoformat(), limit)).fetchall()
    conn.close()
    return rows


def get_overdue_preview(limit=8):
    """Most overdue books first, with the number of days late."""
    today = date.today().isoformat()
    conn = get_connection()
    rows = conn.execute("""
        SELECT b.title, m.name AS member,
               CAST(julianday(?) - julianday(l.due_date) AS INTEGER) AS days_late
        FROM loans l
        JOIN books b   ON b.id = l.book_id
        JOIN members m ON m.id = l.member_id
        WHERE l.return_date IS NULL AND l.due_date < ?
        ORDER BY l.due_date
        LIMIT ?
    """, (today, today, limit)).fetchall()
    conn.close()
    return rows
