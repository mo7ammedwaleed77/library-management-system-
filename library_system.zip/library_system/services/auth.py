"""Authentication: password hashing + login.   Owner: Person 2

Passwords are NEVER stored as plain text. We store  "salt:hash"  produced by PBKDF2.
"""
import hashlib
import hmac
import os

from database.db import get_connection

ITERATIONS = 100_000


def hash_password(password):
    """Turn a plain password into 'salt_hex:hash_hex'."""
    salt = os.urandom(16)                                  # random salt, different for every user
    key = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, ITERATIONS)
    return salt.hex() + ":" + key.hex()


def verify_password(password, stored):
    """Check a plain password against the stored 'salt:hash' string."""
    salt_hex, key_hex = stored.split(":")
    key = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), ITERATIONS)
    return hmac.compare_digest(key.hex(), key_hex)         # safe comparison


def login(username, password):
    """Return the user as a dict (id, username, full_name, role) or None if wrong credentials."""
    conn = get_connection()
    row = conn.execute("SELECT * FROM users WHERE username = ?", (username.strip(),)).fetchone()
    conn.close()
    if row is None or not verify_password(password, row["password_hash"]):
        return None
    return {"id": row["id"], "username": row["username"],
            "full_name": row["full_name"], "role": row["role"]}


def create_user(username, password, full_name, role):
    """Add a new user. Raises sqlite3.IntegrityError if the username already exists."""
    conn = get_connection()
    with conn:
        conn.execute(
            "INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)",
            (username, hash_password(password), full_name, role))
    conn.close()


# TODO (Person 2): list_users(), delete_user(user_id), change_password(user_id, new_password)
