"""Report queries (GROUP BY / COUNT / ORDER BY).   Owner: Person 5

Test every query in DB Browser for SQLite first, then paste it here.
"""
from database.db import get_connection


def most_borrowed_books(limit=10):
    """Report 1 (EXAMPLE - already working): books ranked by number of loans."""
    conn = get_connection()
    rows = conn.execute("""
        SELECT b.title, a.name AS author, COUNT(l.id) AS times_borrowed
        FROM loans l
        JOIN books b   ON b.id = l.book_id
        JOIN authors a ON a.id = b.author_id
        GROUP BY b.id
        ORDER BY times_borrowed DESC, b.title
        LIMIT ?
    """, (limit,)).fetchall()
    conn.close()
    return rows


# ---------------- TODO (Person 5) ----------------
def overdue_books_report():
    """Report 2: currently overdue books, member, days overdue."""
    raise NotImplementedError("TODO: Person 5")


def loans_per_month():
    """Report 3: number of loans per month  (hint: strftime('%Y-%m', loan_date))."""
    raise NotImplementedError("TODO: Person 5")


def books_per_category():
    """Report 4: number of books (and copies) per category."""
    raise NotImplementedError("TODO: Person 5")
