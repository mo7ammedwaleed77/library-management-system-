"""Book operations.   Owner: Person 3

Pattern used everywhere: open connection -> run SQL with ? placeholders -> close.
NEVER build SQL with f-strings (SQL injection). Always use ? placeholders.
"""
from database.db import get_connection


def get_all_books():
    """Return every book with author and category names (EXAMPLE - already working)."""
    conn = get_connection()
    rows = conn.execute("""
        SELECT b.id, b.title, a.name AS author, c.name AS category,
               b.publish_year, b.copies_total, b.copies_available
        FROM books b
        JOIN authors a    ON a.id = b.author_id
        JOIN categories c ON c.id = b.category_id
        ORDER BY b.title
    """).fetchall()
    conn.close()
    return rows


def get_categories():
    conn = get_connection()
    rows = conn.execute("SELECT id, name FROM categories ORDER BY name").fetchall()
    conn.close()
    return rows


# ---------------- TODO (Person 3) ----------------
def search_books(keyword="", category_id=None, status=None):
    """Search by title/author (LIKE) + filter by category and status ('available'/'borrowed')."""
    raise NotImplementedError("TODO: Person 3")


def add_book(title, author_name, category_id, publish_year, copies_total):
    """Find-or-create the author, then INSERT the book (copies_available = copies_total)."""
    raise NotImplementedError("TODO: Person 3")


def update_book(book_id, title, author_name, category_id, publish_year, copies_total):
    raise NotImplementedError("TODO: Person 3")


def delete_book(book_id):
    """Fails with sqlite3.IntegrityError if the book has loans -> show a clear message."""
    raise NotImplementedError("TODO: Person 3")
