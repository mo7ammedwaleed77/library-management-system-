"""Member operations.   Owner: Person 4"""
from database.db import get_connection


def get_all_members():
    """Return all members (EXAMPLE - already working)."""
    conn = get_connection()
    rows = conn.execute("SELECT * FROM members ORDER BY name").fetchall()
    conn.close()
    return rows


# ---------------- TODO (Person 4) ----------------
def search_members(keyword=""):
    raise NotImplementedError("TODO: Person 4")


def add_member(name, phone, email):
    """Validate: name required, email format. Raise ValueError with a clear message."""
    raise NotImplementedError("TODO: Person 4")


def update_member(member_id, name, phone, email):
    raise NotImplementedError("TODO: Person 4")


def delete_member(member_id):
    raise NotImplementedError("TODO: Person 4")
