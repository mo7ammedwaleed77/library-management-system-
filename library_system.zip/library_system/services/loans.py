"""Borrowing / returning books and overdue logic.   Owner: Person 4

Settings (LOAN_DAYS, FINE_PER_DAY) live in config.py.
Dates are ISO strings 'YYYY-MM-DD'; use datetime.date and timedelta to calculate.
"""
from datetime import date, timedelta  # noqa: F401  (you will need these)

from config import FINE_PER_DAY, LOAN_DAYS  # noqa: F401
from database.db import get_connection  # noqa: F401


def borrow_book(book_id, member_id, issued_by):
    """Steps:
    1. Check the book has copies_available > 0, else raise ValueError("No copies available").
    2. INSERT into loans (loan_date = today, due_date = today + LOAN_DAYS).
    3. UPDATE books SET copies_available = copies_available - 1.
    Do steps 2 and 3 inside ONE transaction (`with conn:`).
    """
    raise NotImplementedError("TODO: Person 4")


def return_book(loan_id):
    """Set return_date = today, copies_available + 1. Return the fine (0 if not late)."""
    raise NotImplementedError("TODO: Person 4")


def calculate_fine(due_date, return_date=None):
    """days late * FINE_PER_DAY. If return_date is None, compare with today."""
    raise NotImplementedError("TODO: Person 4")


def get_active_loans():
    """Loans where return_date IS NULL (with book title and member name)."""
    raise NotImplementedError("TODO: Person 4")


def get_overdue_loans():
    """Active loans where due_date < today, with days overdue and fine."""
    raise NotImplementedError("TODO: Person 4")
